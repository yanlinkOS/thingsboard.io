## Flash Firmware & Verify

Your ThingsBoard resources have been created. Now flash the firmware to your ESP32 Dev Kit V4.

### 1. Upload the Sketch

Open Arduino IDE and paste the following sketch:

```cpp
#if defined(ESP8266)
#include <ESP8266WiFi.h>
#define THINGSBOARD_ENABLE_PROGMEM 0
#elif defined(ESP32)
#include <WiFi.h>
#endif

#ifndef LED_BUILTIN
#define LED_BUILTIN 2
#endif

#include <Arduino.h>
#include <array>

#include <Arduino_MQTT_Client.h>
#include <Server_Side_RPC.h>
#include <Attribute_Request.h>
#include <Shared_Attribute_Update.h>
#include <ThingsBoard.h>

constexpr char WIFI_SSID[] = "${wifiSsid}";
constexpr char WIFI_PASSWORD[] = "${wifiPassword}";

constexpr char TOKEN[] = "${device.token}";
constexpr char THINGSBOARD_SERVER[] = "${mqtt.host}";
constexpr uint16_t THINGSBOARD_PORT = ${mqtt.port};
// Serial
constexpr uint32_t SERIAL_DEBUG_BAUD = 115200U;

// Buffer sizes
constexpr uint16_t MAX_MESSAGE_SEND_SIZE = 512U;
constexpr uint16_t MAX_MESSAGE_RECEIVE_SIZE = 512U;
constexpr uint64_t REQUEST_TIMEOUT_MICROSECONDS = 5000ULL * 1000ULL;

// Attribute/RPC config
constexpr size_t MAX_ATTRIBUTES = 2U;
constexpr size_t MAX_RPC_SUBSCRIPTIONS = 1U;
constexpr size_t MAX_RPC_RESPONSE_FIELDS = 5U;
constexpr size_t MAX_SHARED_UPDATE_SUBSCRIPTIONS = 1U;
constexpr size_t MAX_ATTRIBUTE_REQUESTS = 2U;

// Device attributes
constexpr char BLINKING_INTERVAL_ATTR[] = "blinkingInterval";
constexpr char LED_MODE_ATTR[] = "ledMode";
constexpr char LED_STATE_ATTR[] = "ledState";

// Telemetry
constexpr uint32_t TELEMETRY_SEND_INTERVAL_MS = 2000U;

// LED behavior
constexpr uint16_t BLINKING_INTERVAL_MS_MIN = 10U;
constexpr uint16_t BLINKING_INTERVAL_MS_MAX = 60000U;

// Runtime state
volatile bool attributesChanged = false;
volatile uint8_t ledMode = 0;          // 0 = constant, 1 = blinking
volatile bool ledState = false;
volatile uint16_t blinkingInterval = 1000U;

uint32_t previousStateChange = 0U;
uint32_t previousDataSend = 0U;

// Re-subscription flags
bool rpcSubscribed = false;
bool sharedAttrsSubscribed = false;
bool sharedAttrsRequested = false;
bool clientAttrsRequested = false;

// Shared attributes to subscribe/request
constexpr std::array<const char *, 2U> SHARED_ATTRIBUTES_LIST = {
  LED_STATE_ATTR,
  BLINKING_INTERVAL_ATTR
};

// Client attributes to request
constexpr std::array<const char *, 1U> CLIENT_ATTRIBUTES_LIST = {
  LED_MODE_ATTR
};

// Transport
WiFiClient wifiClient;
Arduino_MQTT_Client mqttClient(wifiClient);

// Newer SDK API objects
Server_Side_RPC<MAX_RPC_SUBSCRIPTIONS, MAX_RPC_RESPONSE_FIELDS> rpc;
Attribute_Request<MAX_ATTRIBUTE_REQUESTS, MAX_ATTRIBUTES> attrRequest;
Shared_Attribute_Update<MAX_SHARED_UPDATE_SUBSCRIPTIONS, MAX_ATTRIBUTES> sharedUpdate;

const std::array<IAPI_Implementation*, 3U> apis = {
  &rpc,
  &attrRequest,
  &sharedUpdate
};

// ThingsBoard client
ThingsBoard tb(
  mqttClient,
  MAX_MESSAGE_RECEIVE_SIZE,
  MAX_MESSAGE_SEND_SIZE,
  Default_Max_Stack_Size,
  apis
);

// ---------- Helpers ----------

String formatMac(const uint8_t *mac) {
  char buffer[18];
  snprintf(
    buffer,
    sizeof(buffer),
    "%02X:%02X:%02X:%02X:%02X:%02X",
    mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]
  );
  return String(buffer);
}

String getStationMac() {
  uint8_t mac[6] = {0};
  WiFi.macAddress(mac);
  return formatMac(mac);
}

String getBssid() {
  const uint8_t *bssid = WiFi.BSSID();
  if (bssid == nullptr) {
    return String("");
  }
  return formatMac(bssid);
}

String getLocalIp() {
  IPAddress ip = WiFi.localIP();
  char buffer[16];
  snprintf(buffer, sizeof(buffer), "%u.%u.%u.%u", ip[0], ip[1], ip[2], ip[3]);
  return String(buffer);
}

void resetSubscriptionFlags() {
  rpcSubscribed = false;
  sharedAttrsSubscribed = false;
  sharedAttrsRequested = false;
  clientAttrsRequested = false;
}

void initWiFi() {
  Serial.println("Connecting to AP...");
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println();
  Serial.println("Connected to AP");
  Serial.print("IP: ");
  Serial.println(getLocalIp());
}

bool reconnectWiFi() {
  if (WiFi.status() == WL_CONNECTED) {
    return true;
  }

  Serial.println("Wi-Fi disconnected, reconnecting...");
  initWiFi();
  return WiFi.status() == WL_CONNECTED;
}

bool connectToThingsBoard() {
  if (tb.connected()) {
    return true;
  }

  resetSubscriptionFlags();

  Serial.print("Connecting to ThingsBoard: ");
  Serial.print(THINGSBOARD_SERVER);
  Serial.print(":");
  Serial.println(THINGSBOARD_PORT);

  if (!tb.connect(THINGSBOARD_SERVER, TOKEN, THINGSBOARD_PORT)) {
    Serial.println("Failed to connect to ThingsBoard");
    return false;
  }

  Serial.println("Connected to ThingsBoard");

  tb.sendAttributeData("macAddress", getStationMac().c_str());
  return true;
}

// ---------- RPC / Attribute handlers ----------

void processSetLedMode(const JsonVariantConst &data, JsonDocument &response) {
  Serial.println("Received RPC: setLedMode");

  const int newMode = data.as<int>();

  if (newMode != 0 && newMode != 1) {
    response["error"] = "Unknown mode";
    return;
  }

  ledMode = static_cast<uint8_t>(newMode);
  attributesChanged = true;

  response["newMode"] = ledMode;
}

const std::array<RPC_Callback, 1U> rpcCallbacks = {
  RPC_Callback{ "setLedMode", processSetLedMode }
};

void processSharedAttributes(const JsonObjectConst &data) {
  for (auto it = data.begin(); it != data.end(); ++it) {
    const char *key = it->key().c_str();

    if (strcmp(key, BLINKING_INTERVAL_ATTR) == 0) {
      const uint16_t newInterval = it->value().as<uint16_t>();

      if (newInterval >= BLINKING_INTERVAL_MS_MIN &&
          newInterval <= BLINKING_INTERVAL_MS_MAX) {
        blinkingInterval = newInterval;
        Serial.print("Updated blinking interval: ");
        Serial.println(blinkingInterval);
      }
    } else if (strcmp(key, LED_STATE_ATTR) == 0) {
      ledState = it->value().as<bool>();
      digitalWrite(LED_BUILTIN, ledState ? HIGH : LOW);

      Serial.print("Updated LED state: ");
      Serial.println(ledState);
    }
  }

  attributesChanged = true;
}

void processClientAttributes(const JsonObjectConst &data) {
  for (auto it = data.begin(); it != data.end(); ++it) {
    if (strcmp(it->key().c_str(), LED_MODE_ATTR) == 0) {
      ledMode = it->value().as<uint8_t>();
      Serial.print("Updated LED mode: ");
      Serial.println(ledMode);
    }
  }

  attributesChanged = true;
}

void requestTimedOut() {
  Serial.printf(
    "Attribute request timed out after %llu microseconds\n",
    REQUEST_TIMEOUT_MICROSECONDS
  );
}

const Shared_Attribute_Callback<MAX_ATTRIBUTES> sharedAttributesCallback(
  &processSharedAttributes,
  SHARED_ATTRIBUTES_LIST
);

const Attribute_Request_Callback<MAX_ATTRIBUTES> sharedAttributesRequestCallback(
  &processSharedAttributes,
  REQUEST_TIMEOUT_MICROSECONDS,
  &requestTimedOut,
  SHARED_ATTRIBUTES_LIST
);

const Attribute_Request_Callback<MAX_ATTRIBUTES> clientAttributesRequestCallback(
  &processClientAttributes,
  REQUEST_TIMEOUT_MICROSECONDS,
  &requestTimedOut,
  CLIENT_ATTRIBUTES_LIST
);

// ---------- Subscription helpers ----------

void ensureRpcSubscribed() {
  if (rpcSubscribed || !tb.connected()) {
    return;
  }

  Serial.println("Subscribing for RPC...");
  if (rpc.RPC_Subscribe(rpcCallbacks.cbegin(), rpcCallbacks.cend())) {
    rpcSubscribed = true;
    Serial.println("RPC subscribed");
  } else {
    Serial.println("Failed to subscribe for RPC");
  }
}

void ensureSharedAttributesSubscribed() {
  if (sharedAttrsSubscribed || !tb.connected()) {
    return;
  }

  Serial.println("Subscribing for shared attributes...");
  if (sharedUpdate.Shared_Attributes_Subscribe(sharedAttributesCallback)) {
    sharedAttrsSubscribed = true;
    Serial.println("Shared attributes subscribed");
  } else {
    Serial.println("Failed to subscribe for shared attributes");
  }
}

void ensureAttributeRequestsSent() {
  if (!tb.connected()) {
    return;
  }

  if (!sharedAttrsRequested) {
    Serial.println("Requesting shared attributes...");
    sharedAttrsRequested = attrRequest.Shared_Attributes_Request(
      sharedAttributesRequestCallback
    );

    if (!sharedAttrsRequested) {
      Serial.println("Failed to request shared attributes");
    }
  }

  if (!clientAttrsRequested) {
    Serial.println("Requesting client attributes...");
    clientAttrsRequested = attrRequest.Client_Attributes_Request(
      clientAttributesRequestCallback
    );

    if (!clientAttrsRequested) {
      Serial.println("Failed to request client attributes");
    }
  }
}

// ---------- Arduino ----------

void setup() {
  Serial.begin(SERIAL_DEBUG_BAUD);
  pinMode(LED_BUILTIN, OUTPUT);
  digitalWrite(LED_BUILTIN, LOW);

  delay(1000);
  initWiFi();
}

void loop() {
  delay(10);

  if (!reconnectWiFi()) {
    return;
  }

  if (!connectToThingsBoard()) {
    return;
  }

  tb.loop();

  ensureRpcSubscribed();
  ensureSharedAttributesSubscribed();
  ensureAttributeRequestsSent();

  if (attributesChanged) {
    attributesChanged = false;

    if (ledMode == 0U) {
      previousStateChange = millis();
      digitalWrite(LED_BUILTIN, ledState ? HIGH : LOW);
    }

    tb.sendTelemetryData(LED_MODE_ATTR, ledMode);
    tb.sendTelemetryData(LED_STATE_ATTR, ledState);
    tb.sendAttributeData(LED_MODE_ATTR, ledMode);
    tb.sendAttributeData(LED_STATE_ATTR, ledState);
  }

  if (ledMode == 1U && millis() - previousStateChange > blinkingInterval) {
    previousStateChange = millis();
    ledState = !ledState;

    digitalWrite(LED_BUILTIN, ledState ? HIGH : LOW);

    tb.sendTelemetryData(LED_STATE_ATTR, ledState);
    tb.sendAttributeData(LED_STATE_ATTR, ledState);
  }

  if (millis() - previousDataSend > TELEMETRY_SEND_INTERVAL_MS) {
    previousDataSend = millis();

    tb.sendTelemetryData("temperature", random(10, 20));
    tb.sendAttributeData("rssi", WiFi.RSSI());
    tb.sendAttributeData("channel", WiFi.channel());

    const String bssid = getBssid();
    if (bssid.length() > 0) {
      tb.sendAttributeData("bssid", bssid.c_str());
    }

    tb.sendAttributeData("localIp", getLocalIp().c_str());
    tb.sendAttributeData("ssid", WiFi.SSID().c_str());
  }
}
{:copy-code}
```

### 2. Upload the Sketch to the Board

1. Connect your ESP32 board to the computer using a USB cable.
2. Select the correct serial port in **Tools > Port**.
3. Click **Upload** or press **Ctrl+U**.

As shown below:

![upload-preview.webp](images/upload-preview.webp)

4. Wait until the message **Done uploading** appears in Arduino IDE.

If the upload fails with the following error:

```text
Property 'upload.tool.serial' is undefined
```

Try the following workaround:

1. Go to **Tools > Programmer** and select **Esptool**.
2. Go to **Sketch > Upload Using Programmer**.

${images.gallery(
    {
        src: 'images/select-esptool-programmer-preview.webp',
        caption: ''
    },
    {
        src: 'images/upload-using-programmer-preview.webp',
        caption: ''
    }
)}

### 3. Verify the Device Data

1. Open the **Serial Monitor** in Arduino IDE.
2. Set the baud rate to **115200**.
3. Check that the device prints the connection log.

    ![serial-data-log.webp](images/serial-data-log.webp)
4. Open the **${dashboard.name}** dashboard in ThingsBoard.
5. Verify that telemetry and other device data are displayed correctly.

## Troubleshooting

- **Connection refused:** Make sure the device has network access and can reach your ThingsBoard server. In most cases, the ThingsBoard server runs on a different host than the microcontroller, so you must update the `THINGSBOARD_SERVER` variable manually.

  Do not use `localhost`, because on a microcontroller it refers to the device itself, not to your computer or ThingsBoard server. Replace it with the actual IP address or hostname of your ThingsBoard instance, for example:

  ```cpp
  constexpr char THINGSBOARD_SERVER[] = "192.168.x.x";
- **Upload failed:** Try selecting **Tools > Programmer > Esptool**, then use **Sketch > Upload Using Programmer**.
- **No data in ThingsBoard:** Open the **Serial Monitor** at **115200 baud** and check for connection or authentication errors.
- **Wi-Fi connection failed:** Make sure the Wi-Fi SSID and password in the sketch are correct.
