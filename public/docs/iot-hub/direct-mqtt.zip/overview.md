The ESP32 Dev Kit V4 is a feature-rich development board built around the ESP-WROOM-32 module by Espressif Systems, providing a dual-core Xtensa LX6 CPU with integrated Wi-Fi and Bluetooth for IoT prototyping and production deployments.

## Features

- Dual-core Xtensa 32-bit LX6 at up to 240 MHz (ESP32)
- 520 KB SRAM, 4 MB Flash
- Wi-Fi 802.11 b/g/n + Bluetooth 4.2 / BLE
- 38 GPIO pins, 18 ADC channels, 2 DAC channels
- USB-powered via micro-USB (CP2102 USB-to-UART bridge)
- On-board EN and BOOT buttons

## Specifications

| Parameter | Value |
|-----------|-------|
| SoC | ESP32 (Dual Xtensa LX6) |
| Clock Speed | 80–240 MHz |
| Flash | 4 MB |
| SRAM | 520 KB |
| Operating Voltage | 3.3V |
| Input Voltage | 5V (micro-USB) |
| Wi-Fi | 802.11 b/g/n (2.4 GHz) |
| Bluetooth | Classic + BLE 4.2 |

## Device Technical Documentation

Download datasheets and manuals for the ESP32 Dev Kit V4

${product.button} ${datasheet.button}
