## Prerequisites

Before you begin, make sure you have the following:

- **ESP32 Dev Kit V4** board by Espressif
- **USB cable** (micro-USB) to connect the board to your computer
- **Arduino IDE** installed ([download](https://www.arduino.cc/en/software))

## Arduino IDE Setup

### 1. Add the ESP32 board package URL

1. Open **Arduino IDE**.
2. Go to **File > Preferences**.
3. In **Additional Board Manager URLs**, add:

   ```text
   https://espressif.github.io/arduino-esp32/package_esp32_index.json
   {:copy-code}
   ```

4. Click **OK**.

As shown below:

![preferences-preview.webp](images/preferences-preview.webp)

### 2. Install the ESP32 board package

1. Open **Tools > Board > Boards Manager**.
2. Search for **ESP32**.
3. Install the **ESP32** package published by **Espressif Systems**.

As shown below:

![esp32-arduino-ide-board-manager-preview.webp](images/esp32-arduino-ide-board-manager-preview.webp)


### 3. Select the target board

1. Go to **Tools > Board > ESP32**.
2. Select **ESP32 Dev Module**.

### 4. Connect the device and select the serial port

1. Connect the device to your computer using a USB cable.
2. Open **Tools > Port**.
3. Select the port corresponding to your device.

Examples:

- **Linux:** `/dev/ttyUSB0`, `/dev/ttyUSB1`, ...
- **macOS:** `/dev/cu.usbserial*` or `/dev/cu.usbmodem*`
- **Windows:** `COM3`, `COM4`, ...

The exact port name depends on your operating system and connected hardware.

## Install Arduino IDE Libraries

### 1. Open Library Manager

1. Go to **Sketch > Include Library > Manage Libraries**
   or open it from the **Tools** menu.
2. Search for and install the required libraries listed below.

As shown below:

![tools-manage-libraries-preview.webp](images/tools-manage-libraries-preview.webp)

### 2. Install the required libraries

Install the following libraries one by one from the Library Manager.

#### ThingsBoard

Install **ThingsBoard** version **0.15.0 or later**.

![thingsboard-installation.webp](images/thingsboard-installation.webp)

Then select **INSTALL ALL** option.

![thingsboard-installation-option.webp](images/thingsboard-installation-option.webp)

## Notes

- If the board or port does not appear immediately, reconnect the device and restart Arduino IDE.
- On some systems, you may also need a USB-to-UART driver (CP2102) before the serial port becomes visible.
