## Prerequisites

Before you begin, make sure you have the following:

- reComputer R1000
- Modbus Controller (in our case, [Siemens LOGO!](https://www.siemens.com/ua/uk/produkty/avtomatyzatsiya-promyslovosti/systemy-avtomatyzatsiyi/systemy-promyslovoyi-avtomatyzatsiyi-simatic/plc-kontrolery-simatic/lohichnyy-modul-logo.html))
- [Docker](https://docs.docker.com/engine/install/) installed
