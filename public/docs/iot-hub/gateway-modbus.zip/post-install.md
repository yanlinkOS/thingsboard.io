## Launch Gateway

To launch the newly created "${gateway.name}" gateway, download the docker compose file:

${gateway.downloadButton}

Copy command and execute it in your terminal:

```bash
docker compose up{:copy-code}
```

After running gateway docker image, you can see the following logs in your terminal:

![launch-gateway-docker.webp](images/launch-gateway-docker.webp)

## Verify 

Once connected, data will appear under the device's latest telemetry tab in ThingsBoard.
