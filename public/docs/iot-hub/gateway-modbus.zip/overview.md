The [reComputer R1000](https://wiki.seeedstudio.com/recomputer_r/) edge IoT controller is built on the high-performance
Raspberry Pi CM4 platform, featuring a quad-core A72 processor with a maximum support of 8GB RAM and 32GB eMMC. Equipped
with dual Ethernet interfaces that can be flexibly configured, it also includes 3 isolated RS485 channels supporting
BACnet, Modbus RTU, Modbus TCP/IP protocols. With robust IoT network communication capabilities, the R1000 series
supports multiple wireless communication options including 4G, LoRa®, Wi-Fi/BLE, allowing for flexible configurations to
serve as corresponding wireless gateways. This controller is well-suited for remote device management, energy
management, and various other scenarios in the field of smart buildings.

![logo-and-recomputer-r1000.webp](images/logo-and-recomputer-r1000.webp)

## Device Technical Documentation

Download datasheets and manuals for the reComputer R1000

${product.button} ${datasheet.button}
