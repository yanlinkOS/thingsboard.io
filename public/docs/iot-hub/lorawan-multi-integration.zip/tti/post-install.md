## Verify data

Navigate to the dashboard to view the telemetry and visualized data.

${note(If the event of a data transmission failure, re-read the device state through the application interface to force a refresh.)}
