[AM300 series](https://www.milesight.com/iot/product/lorawan-sensor/am319) is a compact indoor ambiance monitoring
sensor for measurement of temperature, humidity, light, CO2 concentration, barometric pressure, PM2.5, PM10 and motion.
The data will be shown on the E-ink screen in real-time, which helps to measure the indoor environment and comfort.
AM300 series is widely used for offices, stores, classrooms, hospitals, etc. Sensor data is transmitted using LoRaWAN ®
technology. Using Milesight LoRaWAN® gateway and ThingsBoard, users can manage all sensor data remotely and visually.

Features of the AM300 series device:

- Integrated with multiple sensors like humidity, temperature, CO2, level light, barometric pressure, PM2.5, PM10, etc.
  Multiple display modes and clear emoticons to easily understand the comfort levels via screen;
- Support batteries or DC power supply;
- Equipped with traffic light indicator and buzzer to indicate device status and threshold alarms;
- Able to store locally more than 18, 000 records of 512 KB in total;
- Compliant with standard LoRaWAN® gateways and network servers.

## Device Technical Documentation

Download datasheets and manuals for the AM300 series

${product.button} ${datasheet.button}
