## Verify data

Navigate to the dashboard to view the telemetry and visualized data.

${note(If the event of a data transmission failure, re-read the device state through the application interface to force a refresh.)}

## Troubleshooting

If you see the next error message, that means the output was not created automatically.

![loriot-integration-error-pe.webp](images/loriot-integration-error-pe.webp)

You can configure it manually:

- Go to edit mode ThingsBoard Loriot integration, switch off “**Create Loriot Application output**” slider and copy “**HTTP endpoint URL**”. Then, apply changes.
- Now, go to **eu2.loriot.io** than navigate to the “**Output**” page in left panel. Click on “**Add new output**” button.
- Select “**HTTP Push**”. Paste “**HTTP endpoint URL**” in “**Target URL for POSTs**” field. Press “**Add Output**” button.
- Delete default output.
- Go to the cloud and check the connection.

${images.gallery(
    {
        src: 'images/loriot-troubleshootin-1-pe.webp',
        caption: 'Go to edit mode ThingsBoard Loriot integration, switch off “<b>Create Loriot Application output</b>” slider and copy “<b>HTTP endpoint URL</b>”. Then, apply changes.'
    },
    {
        src: 'images/loriot-troubleshootin-2-pe.webp',
        caption: 'Now, go to <b>eu2.loriot.io</b> than navigate to the “<b>Output</b>” page in left panel. Click on “<b>Add new output</b>” button.'
    },
    {
        src: 'images/loriot-troubleshootin-3-pe.webp',
        caption: 'Select “<b>HTTP Push</b>”. Paste “<b>HTTP endpoint URL</b>” in “<b>Target URL for POSTs</b>” field. Press “<b>Add Output</b>” button.'
    },
    {
        src: 'images/loriot-troubleshootin-4-pe.webp',
        caption: 'Delete default output.'
    },
    {
        src: 'images/loriot-troubleshootin-5-pe.webp',
        caption: 'Go to the cloud and check the connection.'
    }
)}
