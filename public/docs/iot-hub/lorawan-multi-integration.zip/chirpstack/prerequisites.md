## Prerequisites

Before you begin, make sure you have the following:

- [AM308 Lorawan 9-IN-1 IAQ Sensor](https://www.milesight.com/iot/product/lorawan-sensor/am319)
- [AM300-series-user-guide](https://resource.milesight.com/milesight/iot/document/am300-series-user-guide-en.pdf)
- Smartphone with NFC-enabled and Milesight ToolBox
  application ([Android](https://play.google.com/store/apps/details?id=com.ursalinknfc)/[iOS](https://itunes.apple.com/app/id1518748039))
- LoRaWAN® gateway (in our case [UG56 LoRaWAN® Gateway](https://www.milesight-iot.com/lorawan/gateway/ug56/))
- [UG56 gateway user manual](https://resource.milesight.com/milesight/iot/document/ug56-user-guide-en.pdf)

## Device connection

According to the [official user manual](https://resource.milesight.com/milesight/iot/document/am300-series-user-guide-en.pdf), we need a smartphone with NFC enabled and the ToolBox application to connect the sensor.
Since this device can only be operated using a LoRaWAN® gateway, we must first connect it to a network server.

To connect and send data we should configure the device and network server. At first we are going to configure the device, and save required information for network server configuration.
To add a device to network server and get information from it, we will need the following device parameters:

- **Device EUI** - device identifier.
- **Application EUI** - Application identifier.
- **Application Key** - Application key to identify device. We recommend to use a generated key, not from the example!

The parameters above are required for connection.

Depending on the network server, you may also need to provide join type (OTAA), LoRaWAN version.

To configure device via NFC, you will need to hold your smartphone like on the picture below:

![am308-connect.webp](images/am308-connect.webp)

To read and write configuration on the device you may follow next steps on your smartphone:

- Open ToolBox application.
- Click on **NFC Read** button and hold your smartphone near the device.
- Go to tab **Setting**, set and save required fields and any other configuration that you need.
- Press **Write** button and hold your smartphone near the device.

${images.gallery(
  { src: 'images/toolbox-application.webp',
    caption: 'Open ToolBox application.'
  },
  {
    src: 'images/toolbox-read-success.webp',
    caption: 'Click on <b>NFC Read</b> button and hold your smartphone near the device.'
  },
  {
    src: 'images/toolbox-configuration.webp',
    caption: 'Go to tab <b>Setting</b>, set and save required fields and any other configuration that you need.'
  },
  {
    src: 'images/toolbox-write-success.webp',
    caption: 'Press <b>Write</b> button and hold your smartphone near the device.'
  }
)}

The developer also provides the possibility of connecting through a computer if necessary:

![am308-connect-to-pc.webp](images/am308-connect-to-pc.webp)

See the [manual](https://resource.milesight.com/milesight/iot/document/am300-series-user-guide-en.pdf) for details.

## Gateway connection

According to the [official user manual](https://resource.milesight.com/milesight/iot/document/ug56-user-guide-en.pdf)
and [this guide](https://support.milesight-iot.com/support/solutions/articles/73000514278-how-to-connect-milesight-gateway-to-the-internet) 
you can connect the gateway to the network and get access to the WebUI in two ways:

- Wireless connection:
    1. Enable Wireless Network Connection on your computer and search for access point “Gateway_**” to connect it.
    2. Open a Web browser on your PC and type in the IP address **192.168.1.1** to access the web GUI.
    3. Enter the username(Default: **admin**) and password(Default: **password**), click “**Login**”.
- Wired connection: Connect PC to UG56 Ethernet port directly or through PoE injector to access the web GUI of gateway.
  The following steps are based on Windows 10 system for your reference.
    1. Go to the “Control Panel” → “Network and Internet” → “Network and Sharing Center”, then click “Ethernet” (May
       have different names).
    2. Go to the “Properties” → “Internet Protocol Version 4(TCP/IPv4)” and select “Use the following IP address”, then
       assign a static IP manually within the same subnet of the gateway.
    3. Open a Web browser on your PC and type in the IP address **192.168.23.150** to access the web GUI.
    4. Enter the username and password, click “**Login**”.

Now you have ability to configure the gateway.

![general-settings-view.webp](images/general-settings-view.webp)

Go to the “**Packet Forwarder**” page in the left menu and save ‘**Gateway EUI**’ and ‘**Gateway ID**’ values. By
default, Gateway EUI and Gateway ID are the same. We will need them to create a gateway on network server.

![ns-configuration-before.webp](images/ns-configuration-before.webp)

Next steps will describe how to connect the gateway to network server.

## Add a gateway on the Chirpstack

We need to add a gateway on the [Chirpstack](https://chirpstack.io/).

To add a gateway, follow next steps:

- Login to Chirpstack server. Go to the “**Gateways**” page and click on the “**Add gateway**” button.
- Fill **name**, **gateway** EUI (It will be different, you can find it on the gateway control panel) with your data, scroll down and click on the “**Submit**” button.
- The gateway is added. In gateways tab you can see its status.

${images.gallery(
  {
    src: 'images/gateways.webp',
    caption: 'Login to Chirpstack server. Go to the “<b>Gateways</b>” page and click on the “<b>Add gateway</b>” button.'
  },
  {
    src: 'images/add-gateway.webp',
    caption: 'Fill <b>name</b>, <b>gateway</b> EUI (It will be different, you can find it on the gateway control panel) with your data, scroll down and click on the “<b>Submit</b>” button.'
  },
  {
    src: 'images/gateway-added-offline.webp',
    caption: 'The gateway is added. In gateways tab you can see its status.'
  }
)}

## Configure the gateway to send data

To connect and send data to the Chirpstack we should configure the gateway.
To do this please follow next steps:

- Open gateway control panel. Go to the “**Packet Forwarder**” page and click on “**plus**” button, to add a new forwarder.
- Put into “**Server address**” your server address, in our case it is **192.168.1.167**. Click “**Save**” button.
- Click “**Save & Apply**” button.
- Now you can check the status of the gateway on Chirpstack, it should be online.

${images.gallery(
  {
    src: 'images/ns-configuration-add-new-forwarder.webp',
    caption: 'Open gateway control panel. Go to the “<b>Packet Forwarder</b>” page and click on “<b>plus</b>” button, to add a new forwarder.'
  },
  {
    src: 'images/ns-chirpstack-configuration-window.webp',
    caption: 'Put into “<b>Server address</b>” your server address, in our case it is <b>192.168.1.167</b>. Click “<b>Save</b>” button.'
  },
  {
    src: 'images/ns-configuration-after.webp',
    caption: 'Click “<b>Save & Apply</b>” button.'
  },
  {
    src: 'images/gateway-added.webp',
    caption: 'Now you can check the status of the gateway on Chirpstack, it should be online.'
  }
)}

Now, the gateway is able to send a data to the network server.

## Configure application on the Chirpstack

Now we need to configure application on the Chirpstack. To do this please follow next steps:

- Go to the “**Applications**” page in the left menu and click on the “**Add application**” button.
- Fill application name and click on the “**Submit**” button.
- In the created application go to the **Integration** tab and click on the “**+**” button under the **ThingsBoard integration**.
- Fill in "**ThingsBoard server**" field with **https://${mqtt.host}** (make attention, if you are running ThingsBoard locally, use your server's actual IP address (e.g., http://192.168.x.x:8080).)

${images.gallery(
  {
    src: 'images/applications.webp',
    caption: 'Go to the “<b>Applications</b>” page in the left menu and click on the “<b>Add application</b>” button.'
  },
  {
    src: 'images/create-application.webp',
    caption: 'Fill application name and click on the “<b>Submit</b>” button.'
  },
  {
    src: 'images/add-thingsboard-integration.webp',
    caption: 'In the created application go to the <b>Integration</b> tab and click on the “<b>+</b>” button under the <b>ThingsBoard integration</b>.'
  },
  {
    src: 'images/submit-thingsboard-integration.webp',
    caption: 'Fill in "<b>ThingsBoard server</b>" field with <b>https://${mqtt.host}</b> (make attention, if you are running ThingsBoard locally, use your server's actual IP address (e.g., http://192.168.x.x:8080).)'
  }
)}
