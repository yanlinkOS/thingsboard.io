## Prerequisites

Before you begin, make sure you have the following:

- [AM308 Lorawan 9-IN-1 IAQ Sensor](https://www.milesight.com/iot/product/lorawan-sensor/am319)
- [AM300-series-user-guide](https://resource.milesight.com/milesight/iot/document/am300-series-user-guide-en.pdf)
- Smartphone with NFC-enabled and Milesight ToolBox
  application ([Android](https://play.google.com/store/apps/details?id=com.ursalinknfc)/[iOS](https://itunes.apple.com/app/id1518748039))
- LoRaWAN® gateway (in our case [UG56 LoRaWAN® Gateway](https://www.milesight-iot.com/lorawan/gateway/ug56/))
- [UG56 gateway user manual](https://resource.milesight.com/milesight/iot/document/ug56-user-guide-en.pdf)

## Device connection

According to the [official user manual](https://resource.milesight.com/milesight/iot/document/am300-series-user-guide-en.pdf), we need a smartphone with NFC enabled and the ToolBox application to connect the sensor.
Since this device can only be operated using a LoRaWAN® gateway, we must first connect it to a network server.

To connect and send data we should configure the device and network server. At first we are going to configure the device, and save required information for network server configuration.
To add a device to network server and get information from it, we will need the following device parameters:

- **Device EUI** - device identifier.
- **Application EUI** - Application identifier.
- **Application Key** - Application key to identify device. We recommend to use a generated key, not from the example!

The parameters above are required for connection.

Depending on the network server, you may also need to provide join type (OTAA), LoRaWAN version.

To configure device via NFC, you will need to hold your smartphone like on the picture below:

![am308-connect.webp](images/am308-connect.webp)

To read and write configuration on the device you may follow next steps on your smartphone:

- Open ToolBox application.
- Click on **NFC Read** button and hold your smartphone near the device.
- Go to tab **Setting**, set and save required fields and any other configuration that you need.
- Press **Write** button and hold your smartphone near the device.

${images.gallery(
    {
        src: 'images/toolbox-application.webp',
        caption: 'Open ToolBox application.'
    },
    {
        src: 'images/toolbox-read-success.webp',
        caption: 'Click on <b>NFC Read</b> button and hold your smartphone near the device.'
    },
    {
        src: 'images/toolbox-configuration.webp',
        caption: 'Go to tab <b>Setting</b>, set and save required fields and any other configuration that you need.'
    },
    {
        src: 'images/toolbox-write-success.webp',
        caption: 'Press <b>Write</b> button and hold your smartphone near the device.'
    }
)}

The developer also provides the possibility of connecting through a computer if necessary:

![am308-connect-to-pc.webp](images/am308-connect-to-pc.webp)

See the [manual](https://resource.milesight.com/milesight/iot/document/am300-series-user-guide-en.pdf) for details.

## Gateway connection

According to the [official user manual](https://resource.milesight.com/milesight/iot/document/ug56-user-guide-en.pdf)
and [this guide](https://support.milesight-iot.com/support/solutions/articles/73000514278-how-to-connect-milesight-gateway-to-the-internet)
you can connect the gateway to the network and get access to the WebUI in two ways:

- Wireless connection:
    1. Enable Wireless Network Connection on your computer and search for access point “Gateway_**” to connect it.
    2. Open a Web browser on your PC and type in the IP address **192.168.1.1** to access the web GUI.
    3. Enter the username(Default: **admin**) and password(Default: **password**), click “**Login**”.
- Wired connection: Connect PC to UG56 Ethernet port directly or through PoE injector to access the web GUI of gateway.
  The following steps are based on Windows 10 system for your reference.
    1. Go to the “Control Panel” → “Network and Internet” → “Network and Sharing Center”, then click “Ethernet” (May
       have different names).
    2. Go to the “Properties” → “Internet Protocol Version 4(TCP/IPv4)” and select “Use the following IP address”, then
       assign a static IP manually within the same subnet of the gateway.
    3. Open a Web browser on your PC and type in the IP address **192.168.23.150** to access the web GUI.
    4. Enter the username and password, click “**Login**”.

Now you have ability to configure the gateway.

![general-settings-view.webp](images/general-settings-view.webp)

Go to the “**Packet Forwarder**” page in the left menu and save ‘**Gateway EUI**’ and ‘**Gateway ID**’ values. By
default, Gateway EUI and Gateway ID are the same. We will need them to create a gateway on network server.

![ns-configuration-before.webp](images/ns-configuration-before.webp)

Next steps will describe how to connect the gateway to network server.

## Add a gateway on The Things Stack Community Edition

We need to add a gateway on [The Things Stack Community Edition](https://console.cloud.thethings.network/).

To add a gateway, you can follow next steps:

- Login to the cloud and open your console.
- Select the “**Register a gateway**”.
- Press the “**Register gateway**” button.
- Put information about the gateway (gateway EUI) and click the “**Register gateway**” button.
- The gateway is added. You can see its status - disconnected.

${images.gallery(
    {
        src: 'images/1-tts-login.webp',
        caption: 'Login to the cloud and open your console.'
    },
    {
        src: 'images/2-welcome-screen.webp',
        caption: 'Select the “<b>Register a gateway</b>”.'
    },
    {
        src: 'images/3-gateway-list.webp',
        caption: 'Press the “<b>Register gateway</b>” button.'
    },
    {
        src: 'images/4-register-gateway.webp',
        caption: 'Put information about the gateway (gateway EUI) and click the “<b>Register gateway</b>” button.'
    },
    {
        src: 'images/5-gateway-info.webp',
        caption: 'The gateway is added. You can see its status - disconnected.'
    }
)}

## Configure the gateway to send data

To connect and send data to The Things Stack Community Edition we should configure the gateway.
To do this please follow next steps:

- Open gateway control panel. Go to the “**Packet Forwarder**” page and click on “**plus**” button, to add a new forwarder.
- Put into **Server address** your server address, in our case it is **eu1.cloud.thethings.network**. Click “**Save**” button.
- Click “**Save & Apply**” button.

${images.gallery(
    {
        src: 'images/ns-configuration-add-new-forwarder.webp',
        caption: 'Open gateway control panel. Go to the “<b>Packet Forwarder</b>” page and click on “<b>plus</b>” button, to add a new forwarder.'
    },
    {
        src: 'images/ns-chirpstack-thethingsstack-configuration-window.webp',
        caption: 'Put into <b>Server address</b> your server address, in our case it is <b>eu1.cloud.thethings.network</b>. Click “<b>Save</b>” button.'
    },
    {
        src: 'images/ns-configuration-thethingsstack-after.webp',
        caption: 'Click “<b>Save & Apply</b>” button.'
    }
)}

Now, the gateway is able to send a data to the network server.

## Configure application on The Things Stack Community Edition

Now we need to configure application on The Things Stack. To do this please follow next steps:

- Open your console and click on the “**Create an application**”.
- Fill in the required fields about the application. Then click “**Create application**” button.
- Go to the “**Integrations**” -> open the “**MQTT**” page in the left menu. Then, click on the “**Generate new API key**” button.
- Copy and save the **password** (API key) (after leaving the page it won't be displayed).

${images.gallery(
    {
        src: 'images/2-welcome-screen-application.webp',
        caption: 'Open your console and click on the “<b>Create an application</b>”.'
    },
    {
        src: 'images/3-create-application.webp',
        caption: 'Fill in the required fields about the application. Then click “<b>Create application</b>” button.'
    },
    {
        src: 'images/5-generate-new-api-key.webp',
        caption: 'Go to the “<b>Integrations</b>” -> open the “<b>MQTT</b>” page in the left menu. Then, click on the “<b>Generate new API key</b>” button.'
    },
    {
        src: 'images/6-copy-access-key.webp',
        caption: 'Copy and save the <b>password</b> (API key) (after leaving the page it won't be displayed).'
    }
)}

## Add a device on The Things Stack Community Edition

To add a device, you can follow next steps:

- Go to the **Applications** page. Then select your application and click on its name.
- Click on the **Register end device** button.
- Put the **APP EUI** value to the **JoinEUI** field. Press the **Confirm** button.
- Fill the rest parameters and press **Register end device** button.

${images.gallery(
    {
        src: 'images/create-device-step-0-ttn.webp',
        caption: 'Go to the <b>Applications</b> page. Then select your application and click on its name.'
    },
    {
        src: 'images/create-device-step-1-ttn.webp',
        caption: 'Click on the <b>Register end device</b> button.'
    },
    {
        src: 'images/create-device-step-3-ttn.webp',
        caption: 'Put the <b>APP EUI</b> value to the <b>JoinEUI</b> field. Press the <b>Confirm</b> button.'
    },
    {
        src: 'images/create-device-step-4-ttn.webp',
        caption: 'Fill the rest parameters and press <b>Register end device</b> button.'
    }
)}
