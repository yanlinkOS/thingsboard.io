## Generated HTTP endpoint URL

HTTP Endpoint:

```text
${integration.httpEndpoint}{:copy-code}
```

## Add integration to Chirpstack application

We need to add an HTTP integration to the created Chirpstack application, for this purpose use the following steps:

- Open your Chirpstack, go to the “**Applications**” page -> Your application -> “**Integrations**” tab, Find and click on the **HTTP** tile.
- Put “**HTTP URL endpoint**” into “**Event Endpoint URL(s)**” field and click on “**Submit**” button.

${images.gallery(
    {
        src: 'images/application-integrations.webp',
        caption: 'Open your Chirpstack, go to the “<b>Applications</b>” page -> Your application -> “<b>Integrations</b>” tab, Find and click on the <b>HTTP</b> tile.'
    },
    {
        src: 'images/create-application-integration.webp',
        caption: 'Put “<b>HTTP URL endpoint</b>” into “<b>Event Endpoint URL(s)</b>” field and click on “<b>Submit</b>” button.'
    }
)}

## Add a device on the Chirpstack

To add a device, you can follow next steps:

- Login to Chirpstack server.
- Go to the **Device profiles** page and click on **Add device profile** button.
- Fill the fields and click on **Submit** button.
- Go to the **Applications** page, click on your application and press **Add device** button.
- Fill parameters with values from the device configuration. Then choose previously created device profile and click on **Submit** button.
- Put your **Application key** to the field and click on **Submit** button to save the device.

${images.gallery(
    {
        src: 'images/main-page.webp',
        caption: 'Login to Chirpstack server.'
    },
    {
        src: 'images/add-device-profile.webp',
        caption: 'Go to the <b>Device profiles</b> page and click on <b>Add device profile</b> button.'
    },
    {
        src: 'images/create-device-profile.webp',
        caption: 'Fill the fields and click on <b>Submit</b> button.'
    },
    {
        src: 'images/create-device-step-0.webp',
        caption: 'Go to the <b>Applications</b> page, click on your application and press <b>Add device</b> button.'
    },
    {
        src: 'images/create-device-step-1.webp',
        caption: 'Fill parameters with values from the device configuration. Then choose previously created device profile and click on <b>Submit</b> button.'
    },
    {
        src: 'images/create-device-step-2.webp',
        caption: 'Put your <b>Application key</b> to the field and click on <b>Submit</b> button to save the device.'
    }
)}

## Verify data

Navigate to the dashboard to view the telemetry and visualized data.

${note(If the event of a data transmission failure, re-read the device state through the application interface to force a refresh.)}
